//
//  main.cpp
//  HDU A + B Problem
//
//  Created by tly on 2017/8/17.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>

int main()
{
    int a, b;
    while (scanf("%d%d", &a, &b) != EOF) printf("%d\n", a + b);
    return 0;
}
