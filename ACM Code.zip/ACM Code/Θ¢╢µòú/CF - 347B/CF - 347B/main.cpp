//
//  main.cpp
//  CF - 347B
//
//  Created by tly on 2017/8/20.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;
const int maxn = 100005;

int a[maxn];

int main()
{
    int n;
    scanf ("%d", &n);
    
    int ans = 0;
    int k = 0;
    
    for (int i = 0; i < n; i++)
        scanf ("%d", &a[i]);
    
    for (int i = 0; i < n; i++)
    {
        if (a[i] == i) ans++;
        else if (a[a[i]] == i) k = 1;
    }
    
    if (ans < n) ans++;
    ans += k;
    printf ("%d\n", ans);
}
