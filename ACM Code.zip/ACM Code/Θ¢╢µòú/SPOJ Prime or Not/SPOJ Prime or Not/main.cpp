//
//  main.cpp
//  SPOJ Prime or Not
//
//  Created by tly on 2017/8/17.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cmath>
#include <cstdio>
using namespace std;
typedef long long ll;

bool is_prime (ll n)
{
    if (n % 2 == 0) return false;
    for (int i = 3; i < sqrt(n); i +=2)
        if (n % i == 0) return false;
    return true;
}

int main()
{
    int t;
    scanf("%d", &t);
    while (t--)
    {
        ll a;
        scanf("%lld", &a);
        if (is_prime(a)) printf("YES\n");
        else printf("NO\n");
    }
    return 0;
}
