//
//  main.cpp
//  D. 转头
//
//  Created by Nick Tan on 2018/1/13.
//  Copyright © 2018年 Nick Tan. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    int n;
    cin >> n;
    if (n % 2) cout << "NO" << endl;
    else cout << n << endl;
}
