//
//  main.cpp
//  i love you
//
//  Created by tly on 2017/9/9.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    int a;
    while (scanf("%d", &a) != EOF)
        printf("%c ", a + 100);
    return 0;
}
