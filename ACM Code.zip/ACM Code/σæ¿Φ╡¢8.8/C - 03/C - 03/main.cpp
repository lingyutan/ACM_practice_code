//
//  main.cpp
//  C - 03
//
//  Created by tly on 2017/8/8.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
using namespace std;

int n;
int a[100005];
char b[100005];
int dp = 0;
int main()
{
    scanf ("%d", &n);
    for (int i = 0; i < n; i++)
        scanf ("%d", &a[i]);
    scanf("%s", b);
    int ans = 0;
    for (int i = 0; i < n; i++)
    {
        while(b[i] == '0')
        {
            dp += a[i];
            i++;
        }
        if(b[i] == '1')
        {
            if (dp > a[i])
            {
                ans += dp;
                dp = a[i];
            }
            else ans += a[i];
        }
    }
    printf("%d\n", ans);
}
