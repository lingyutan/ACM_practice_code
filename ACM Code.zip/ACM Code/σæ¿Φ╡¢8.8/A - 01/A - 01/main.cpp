//
//  main.cpp
//  A - 01
//
//  Created by tly on 2017/8/8.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    int n;
    scanf("%d", &n);
    int a[n][2];
    int b[3] = {0, 0, 0};
    int x, y;
    for (int i = 0; i < n; i++)
    {
        scanf ("%d%d", &x, &y);
        a[i][0] = x % 2;
        a[i][1] = y % 2;
    }
    for (int i = 0; i < n; i++)
    {
        if (a[i][0] == 1 && a[i][1] == 1) b[0]++;
        if (a[i][0] == 0 && a[i][1] == 1) b[1]++;
        if (a[i][0] == 1 && a[i][1] == 0) b[2]++;
    }
    int ans = 0;
    if (b[0] % 2 == 0)
    {
        if (b[1] % 2 == 0 && b[2] % 2 == 0) ans = 0;
        if (b[1] % 2 == 1 && b[2] % 2 == 0) ans = -1;
        if (b[1] % 2 == 0 && b[2] % 2 == 1) ans = -1;
        if (b[1] % 2 == 1 && b[2] % 2 == 1) ans = 1;
    }
    else
    {
        if (b[1] % 2 == 0 && b[2] % 2 == 0) ans = 1;
        if (b[1] == 0 && b[2] == 0) ans = -1;
        if (b[1] % 2 == 1 && b[2] % 2 == 0) ans = -1;
        if (b[1] % 2 == 0 && b[2] % 2 == 1) ans = -1;
        if (b[1] % 2 == 1 && b[2] % 2 == 1) ans = 0;
    }
    printf ("%d\n", ans);
}
