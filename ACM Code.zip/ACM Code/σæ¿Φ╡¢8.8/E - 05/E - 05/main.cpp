//
//  main.cpp
//  E - 05
//
//  Created by tly on 2017/8/8.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <cstdio>
using namespace std;
const int maxn = 100005;

int n, l ,r;
struct element
{
    int num;
    int order;
    int plus;
}s[maxn];
int p[maxn];

bool cmp(element a, element b)
{
    return a.order < b.order;
}

int main()
{
    cin >> n >> l >> r;
    for (int i = 0; i < n; i++)
    {
        scanf ("%d", &s[i].num);
        s[i].num = -s[i].num;
    }
    for (int i = 0; i < n; i++)
    {
        scanf ("%d", &p[i]);
        s[i].order = p[i];
    }
    
    sort(s, s + n, cmp);
    
    s[0].num += l;
    s[0].plus = l;
    
    for (int i = 1; i < n; i++)
    {
        if(s[i].num + l > s[i - 1].num)
        {
        s[i].num += l;
        s[i].plus = l;
        }
        else
        {
            s[i].plus = s[i - 1].num + 1 - s[i].num;
            s[i].num = s[i - 1].num + 1;
        }
        if (s[i].plus > r)
        {
            printf("-1\n");
            return 0;
        }
    }
    
    for (int i = 0; i < n; i++)
        printf("%d ", s[p[i] - 1].plus);
}
