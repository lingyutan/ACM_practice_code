//
//  main.cpp
//  D - 04
//
//  Created by tly on 2017/8/10.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

char line[1000005];

int main()
{
    scanf ("%s", line);
    int len = (int) strlen(line);
    int p = 0, m = 0, ans = 0;
    while (line[p] == 'F') p++;
    for (int i = p; i < len; i++)
    {
        if (line[i] == 'M') m++;
        else ans = max(ans + 1, m);
    }
    printf ("%d", ans);
}
