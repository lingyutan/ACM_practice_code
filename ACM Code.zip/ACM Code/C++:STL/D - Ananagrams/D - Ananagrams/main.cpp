//
//  main.cpp
//  D - Ananagrams
//
//  Created by tly on 2017/7/28.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <set>
using namespace std;
set <string> word;
string str;

int main()
{
    while(cin >> str)
    {
        
    }
}
