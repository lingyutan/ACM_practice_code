//
//  main.cpp
//  A - Knight Moves
//
//  Created by tly on 2017/8/5.
//  Copyright © 2017年 admin. All rights reserved.
//
#include <iostream>
#include <queue>
using namespace std;

char c1, c2;
int d1, d2;
int ans;
int flag[8][8];
int op[8][2] = {{2,1},{2,-1},{-2,1},{-2,-1},{1,-2},{1,2},{-1,-2},{-1,2}};

struct Node{
    int X;
    int Y;
    int step;
};

bool check(Node x)
{
    if (x.X < 0 || x.X > 7) return false;
    if (x.Y < 0 || x.Y > 7) return false;
    return true;
}

void bfs()
{
    queue <Node> Q;
    Node start;
    start.X = c1 - 'a';
    start.Y = d1 - 1;
    start.step = 0;
    Q.push(start);
    
    flag[c1 - 'a'][d1 - 1] = 1;
    
    while (!Q.empty())
    {
        Node temp = Q.front();
        Q.pop();
        
        if (temp.X == c2 - 'a' && temp.Y == d2 - 1)
        {
            ans = temp.step;
            break;
        }
        
        for (int i = 0; i < 8; i++)
        {
            Node p;
            p.X = temp.X + op[i][0];
            p.Y = temp.Y + op[i][1];
            
            if (check(p) && !flag[p.X][p.Y])
            {
                flag[p.X][p.Y] = 1;
                p.step = temp.step + 1;
                Q.push(p);
            }
        }
        
    }
    
}

int main()
{
    
    while (scanf("%c%d%*c%c%d%*c",&c1, &d1, &c2, &d2) != EOF)
    {
        memset(flag, 0, sizeof(flag));
        ans = 0;
        bfs();
        printf("To get from %c%d to %c%d takes %d knight moves.\n", c1, d1, c2, d2, ans);
    }
    return 0;
}
