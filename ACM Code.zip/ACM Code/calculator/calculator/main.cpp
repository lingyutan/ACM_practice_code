//
//  main.cpp
//  calculator
//
//  Created by Nick Tan on 2018/3/25.
//  Copyright © 2018年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    double a = (5 + 12.5 + 125.0/6) * exp(-5);
    cout << a << endl;
}
