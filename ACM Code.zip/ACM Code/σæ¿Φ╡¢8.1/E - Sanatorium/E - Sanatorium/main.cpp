//
//  main.cpp
//  E - Sanatorium
//
//  Created by tly on 2017/8/1.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int main()
{
    long long a[3];
    cin >> a[0] >> a[1] >> a[2];
    sort (a,a+3);
    long long ans = 0;
    if (a[2] - a[0] <= 1) ans = 0;
    if (a[2] - a[0] > 1)ans += a[2] - a[0] - 1;
    if (a[2] - a[1] > 1) ans += a[2] - a[1] - 1;
    cout << ans << endl;
}
