//
//  main.cpp
//  B - Wet Shark and Bishops
//
//  Created by tly on 2017/8/1.
//  Copyright © 2017年 admin. All rights reserved.
//
#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int a[200000][2];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            scanf ("%d",&a[i][j]);
        }
            }
    int max = a[0][0];
    for (int i = 0; i < n; i++)
        for (int j = 0; j < 2; j++)
        {
            if (max < a[i][j]) max = a[i][j];
        }
    int b[2 * max - 1];
    int c[2 * max - 1];
    for (int i = 0; i < 2 * max - 1; i++)
    {
        b[i] = 0;
        c[i] = 0;
    }
    for (int i = 0; i < n; i++)
    {
    b[a[i][1] - a[i][0] + max - 1]++;
    c[a[i][1] + a[i][0] - 2]++;
    }
    long long sum = 0;
    for (int i = 0; i < 2 * max - 1; i++)
    {
        if (b[i] > 1) sum += b[i] * (b[i] - 1) / 2;
        if (c[i] > 1) sum += c[i] * (c[i] - 1) / 2;
    }
    cout << sum << endl;
}
