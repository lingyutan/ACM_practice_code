//
//  main.cpp
//  C - Chocolate
//
//  Created by tly on 2017/8/1.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
    int n;
    cin >> n;
    int a[n];
    int sum = 0;
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
        sum += a[i];
    }
    long long ans = 1;
    if (sum == 0) ans = 0;
    else
    {
    int b[sum - 1];
    for (int i = 0; i < sum - 1; i++) b[i] = 0;
    int k = 0;
    int num = 0;
    int k0 = 0;
    for (int i = 0; i < n; i++)
    {
        if (a[i] == 0 && k == 0) continue;
        if (a[i] == 1 && num < sum - 1)
        {
            k = 1;
            b[num]++;
            while(a[i + 1] == 0)
            {
                b[num]++;
                k0 = 1;
                i++;
            }
            if (k0 == 1)
            {
                i--;
                k0 = 0;
            }
            num++;
        }
    }
    for (int i = 0; i < sum - 1; i++)
        ans *= b[i];
    }
    cout << ans << endl;
}
