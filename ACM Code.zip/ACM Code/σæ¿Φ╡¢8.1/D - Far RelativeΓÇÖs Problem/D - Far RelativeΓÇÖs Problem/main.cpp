//
//  main.cpp
//  D - Far Relative’s Problem
//
//  Created by tly on 2017/8/1.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
    int n;
    cin >> n;
    struct relative
    {
        char gender;
        int begin_day;
        int end_day;
    }ifo[n];
    int num[366];
    for (int i = 0; i < 366; i++) num[i] = 0;
    for (int i = 0; i < n; i++)
        cin >> ifo[i].gender >> ifo[i].begin_day >> ifo[i].end_day;
    for (int i = 1; i <= 366; i++)
    {
        int F = 0; int M = 0;
        for(int j = 0; j < n; j++)
        if (i >= ifo[j].begin_day && i <= ifo[j].end_day)
        {
            if (ifo[j].gender == 'F') F++;
            if (ifo[j].gender == 'M') M++;
        }
        num[i - 1] = 2 * min(F,M);
    }
    int ans = num[0];
    for (int i = 1; i < 366; i++)
        if (num[i] > ans) ans = num[i];
    cout << ans << endl;
    
}
