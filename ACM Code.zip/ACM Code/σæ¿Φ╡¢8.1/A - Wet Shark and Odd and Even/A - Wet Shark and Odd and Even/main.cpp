//
//  main.cpp
//  A - Wet Shark and Odd and Even
//
//  Created by tly on 2017/8/1.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
    int n;
    cin >> n;
    int a[n];
    for (int i = 0; i < n; i++)
        scanf ("%d",&a[i]);
    long long sum = 0;
    for (int i = 0; i < n; i++)
        sum += a[i];
    int min = 999999999;
    if (sum % 2 == 0) cout << sum << endl;
    else
    {
        for (int i = 0; i < n; i++)
        if (a[i] % 2 == 1 && a[i] < min)
        {
            min = a[i];
        }
        cout << sum - min << endl;
    }
}
