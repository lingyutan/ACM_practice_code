//
//  main.cpp
//  D - Cleaning Shifts
//
//  Created by tly on 2017/8/3.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <algorithm>
using namespace std;


struct work
{
    int start;
    int end;
} cow[25000];

bool cmp(work a, work b)
{
    if (a.end == b.end) return (a.start < b.start);
    return (a.end > b.end);
}

int main()
{
    int N, T;
    scanf ("%d%d", &N, &T);
    for (int i = 0; i < N; i++)
        scanf ("%d%d", &cow[i].start, &cow[i].end);
    sort (cow, cow + N, cmp);
    int r = 1;
    int ans = 0;
    int M = N;
    int i,k;
    if (T == 1)
        for (int j = 0; j < N; j++)
            if(cow[j].start == 1)
            {
                printf("1\n");
                return 0;
            }
    while (r < T)
    {
        k = 0;
        for (i = 0; i < M; i++)
            if (cow[i].start <= r)
            {
                r = cow[i].end;
                M = i;
                ans++;
                k++;
                break;
            }
        if (k == 0)
        {
            printf ("-1\n");
            return 0;
        }
    }
    printf ("%d\n", ans);
}
