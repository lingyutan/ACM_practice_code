//
//  main.cpp
//  A - Game Prediction
//
//  Created by tly on 2017/7/30.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <set>
using namespace std;
set <int> num1, num2;
int main()
{
    int m, n;
    int k = 1;
    while (cin >> m >> n && m != 0 && n != 0)
    {
        num1.clear(); num2.clear();
        for (int i = 0; i < n; i++)
        {
            int x;
            cin >> x;
            num1.insert(x);
        }
        set <int> :: iterator iter = num1.end(); iter--;
        for (int i = m * n, k = 0; i > (m - 2)* n && k < n; i--)
        {
            if(i == *iter) iter--;
            else
            {
                num2.insert(i);
                k++;
            }
        }
        set <int> :: iterator iter1 = num1.end(); iter1--;
        set <int> :: iterator iter2 = num2.end(); iter2--;
        int ans = 0;
        for (int i = 0; i < n; i++)
        {
            if (*iter1 > *iter2)
            {
            iter1--;
            ans++;
            }
                else
                {
                iter1--;
                iter2--;
                }
        }
        cout << "Case " << k << ": " << ans << endl;
        k++;
    }
}
