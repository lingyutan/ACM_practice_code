//
//  main.cpp
//  B - Doing Homework again
//
//  Created by tly on 2017/7/31.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <algorithm>
using namespace std;
const int maxn = 1005;
int b[maxn];
struct homework
        {
            int deadline;
            int score;
            bool flag;
        }a[maxn];

bool cmp (homework a, homework b)
        {
            if (a.deadline == b.deadline) return a.score > b.score;
            return a.deadline < b.deadline;
        }


int main()
{
    int T;
    cin >> T;
    while (T--)
    {
        int N;
        scanf ("%d", &N);
        int sum = 0;
        int ans = 0;
        for(int i = 0; i < N; i++) cin >> a[i].deadline;
        for(int i = 0; i < N; i++) cin >> a[i].score;
        for (int i = 0; i < N; i++){
            
        }
        sort (a, a + N, cmp);
    }
    return 0;
}
