//
//  main.cpp
//  F - Ball in a Rectangle
//
//  Created by tly on 2017/9/17.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;

const double pi = 3.141592653589;

int main()
{
    double L, W, x, y, R, a, v, s;
    while (scanf ("%lf%lf%lf%lf%lf%lf%lf%lf", &L, &W, &x, &y, &R, &a, &v, &s)
           && (L||W||x||y||R||a||v||s))
    {
        double xc, yc;
        
        xc = v * cos (a / 180 * pi) * s;
        yc = v * sin (a / 180 * pi) * s;
        
        x += xc - R;
        y += yc - R;
        
        L -= 2 * R;
        W -= 2 * R;
        
        while (x < 0) x += 2 * L;
        while (x > 2 * L) x -= 2 * L;
        if (x > L) x = 2 * L - x;
        
        while (y < 0) y += 2 * W;
        while (y > 2 * W) y -= 2 * W;
        if (y > W) y = 2 * W - y;
        
        x += R;
        y += R;
        
        printf ("%.2f %.2f\n", x, y);
    }
    
}

//Wrong Answer
