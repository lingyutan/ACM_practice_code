//
//  main.cpp
//  G - Letter
//
//  Created by Nick Tan on 2017/11/13.
//  Copyright © 2017年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    char a[50][50];
    int n, m;
    scanf ("%d%d", &n, &m);
    int min1, min2, max1, max2;
    for (int i = 0; i < n; i++)
        scanf ("%s", a[i]);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            if (a[i][j] == '*'){
                min1 = i;
                break;
            }
    
}
