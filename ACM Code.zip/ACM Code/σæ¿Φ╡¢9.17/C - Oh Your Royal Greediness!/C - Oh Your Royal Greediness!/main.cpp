//
//  main.cpp
//  C - Oh Your Royal Greediness!
//
//  Created by tly on 2017/9/17.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

struct ffff
{
    int start;
    int end;
}farmer[1005];

int main()
{
    int N;
    int k = 0;
    while (++k && scanf("%d", &N) && N != -1)
    {
        for (int i = 0; i < N; i++)
            scanf ("%d%d", &farmer[i].start, &farmer[i].end);
        
        int ans = 0;
        
        for (int i = 0; i < N; i++)
        {
            int maxn = 0;
            for (int j = 0; j < N; j++)
                if (farmer[i].end >= farmer[j].start && farmer[i].end <= farmer[j].end) maxn++;
            
            if (maxn > ans) ans = maxn;
        }
        printf ("Case %d: %d\n", k, ans);
    }
    
    return 0;
}
