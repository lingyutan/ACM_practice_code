//
//  main.cpp
//  E - Internal Rate of Return
//
//  Created by tly on 2017/9/17.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;

const double eps = 1e-6;

double cf[15];
int T;

double npv(double irr)
{
    double temp = cf[0];
    for (int i = 1; i <= T; i++)
    {
        temp += cf[i] / pow((1 + irr), i);
    }
    return temp;
}

int main()
{
    while (scanf ("%d", &T) && T)
    {
        for (int i = 0; i <= T; i++)
            scanf ("%lf", &cf[i]);
        
        double l = -1.0;
        double r = 100000;
        
        while (r - l > eps)
        {
            double m;
            m = (l + r) / 2;
            if (npv(m) < 0) r = m;
            else l = m;
        }
        printf ("%.2f\n", l);
    }
    return 0;
}
