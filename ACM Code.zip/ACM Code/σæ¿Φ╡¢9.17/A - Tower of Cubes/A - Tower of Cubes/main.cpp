//
//  main.cpp
//  A - Tower of Cubes
//
//  Created by tly on 2017/9/17.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    
}

//DP
