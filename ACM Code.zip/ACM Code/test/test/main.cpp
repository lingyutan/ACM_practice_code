//
//  main.cpp
//  test
//
//  Created by Nick Tan on 2018/1/11.
//  Copyright © 2018年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int i, j;
    float x;
    scanf("%d%f%d", &i, &x, &j);
    cout << i << " "<< x << " " << j;
}
