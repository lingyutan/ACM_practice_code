//
//  main.cpp
//  大数乘法
//
//  Created by Nick Tan on 2018/1/12.
//  Copyright © 2018年 Nick Tan. All rights reserved.
//

#include<iostream>
#include<string.h>
using namespace std;
//定义MAX_SIZE
#define MAX_SIZE 1000
//定义两个char[]来存放输入的string类型
char charArrOne[MAX_SIZE+10];
char charArrTwo[MAX_SIZE+10];
int intArrOne[MAX_SIZE+10];
int intArrTwo[MAX_SIZE+10];
int resultArr[MAX_SIZE*2+1];
//定义两个int[]来存放最后的结果
int main()
{
    //输入两个参数
    //while(scanf("%s %s",charArrOne,charArrTwo))
    scanf("%s %s",charArrOne,charArrTwo);
    {
        memset(intArrOne,0,sizeof(intArrOne));
        memset(intArrTwo,0,sizeof(intArrTwo));
        memset(resultArr,0,sizeof(resultArr));
        for(int i=strlen(charArrOne)-1,j=0;i>=0;i--,j++)
        {
            intArrOne[j]=charArrOne[i]-'0';
            //这一边的  -‘0’不能忘记或者是用map映射过去也是相同的
        }
        for(int i=strlen(charArrTwo)-1,j=0;i>=0;i--,j++)
        {
            intArrTwo[j]=charArrTwo[i]-'0';
        }
        //计算
        for(int i=0;i<MAX_SIZE;i++)
        {
            for(int j=0;j<MAX_SIZE;j++)
            {
                resultArr[i+j]+=intArrOne[i]*intArrTwo[j];
            }
        }
        //进位处理
        for(int i=0;i<MAX_SIZE*2;i++)
        {
            resultArr[i+1]+=resultArr[i]/10;
            resultArr[i]=resultArr[i]%10;
        }
        //最终结果的输出(后面的一大串0不用输出)
        bool flag=false;
        for(int i=MAX_SIZE*2-1;i>=0;i--)
        {
            if(flag)
            {
                cout<<resultArr[i];
            }
            else if(resultArr[i]!=0)
            {
                cout<<resultArr[i];
                flag=true;
            }
        }
        cout<<endl;
    }
    
}
