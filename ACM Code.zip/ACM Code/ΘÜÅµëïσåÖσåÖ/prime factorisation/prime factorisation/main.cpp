//
//  main.cpp
//  prime factorisation
//
//  Created by Nick Tan on 2018/3/26.
//  Copyright © 2018年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <cmath>
#include <cstdio>
#include <algorithm>
using namespace std;

int main()
{
    int n;
    while(scanf("%d", &n) != 0)
    {
        while(n != 1)
        {
            for (int i = 2; i < 100000; i++)
            {
                if(n % i == 0)
                {
                    cout << i << ' ';
                    n /= i;
                    break;
                }
            }
        }
        cout << endl;
    }
    return 0;
}

