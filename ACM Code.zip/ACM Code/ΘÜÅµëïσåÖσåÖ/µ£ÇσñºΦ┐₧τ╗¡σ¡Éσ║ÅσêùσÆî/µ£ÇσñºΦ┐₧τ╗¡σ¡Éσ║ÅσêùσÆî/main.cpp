//
//  main.cpp
//  最大连续子序列和
//
//  Created by Nick Tan on 2018/1/12.
//  Copyright © 2018年 Nick Tan. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int num;
    int sum = 0;
    int ans = 0;
    for (int i = 0; i < n; i++)
    {
        cin >> num;
        sum += num;
        if (sum > ans) ans = sum;
        if (sum < 0) sum = 0;
    }
    cout << ans << endl;
}
