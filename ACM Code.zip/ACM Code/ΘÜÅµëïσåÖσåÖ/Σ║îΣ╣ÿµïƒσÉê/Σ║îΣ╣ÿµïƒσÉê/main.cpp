//
//  main.cpp
//  二乘拟合
//
//  Created by Nick Tan on 2018/6/7.
//  Copyright © 2018年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    float y[5] = {-8.99, -1.51, 0.001, 1.47, 9.02};
    float x[5] = {-2, -1, 0, 1, 2};
    double sum = 0;
    for (int i = 0; i < 5; i++)
        sum += y[i] * pow(x[i], 3);
    
    cout << sum << endl;
}
