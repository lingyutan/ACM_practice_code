//
//  main.cpp
//  大数加法
//
//  Created by Nick Tan on 2018/1/13.
//  Copyright © 2018年 Nick Tan. All rights reserved.
//

#include <iostream>
using namespace std;

const int M = 5000;
int num1[M], num2[M];
void Add(char s1[],char s2[]) //需要两个字符串参数&&无返回值
{
    int i,j;
    int len1, len2;
    len1 = strlen(s1);
    len2 = strlen(s2);
    for(i=len1-1,j=0;i>=0;i--)//num[0]保存的是低位
        num1[j++]=s1[i]-'0';
    for(i=len2-1,j=0;i>=0;i--)
        num2[j++]=s2[i]-'0';
    for(i=0;i<M;i++)
    {
        num1[i]+=num2[i];
        if(num1[i]>9)
        {
            num1[i]-=10;
            num1[i+1]++;
        }
    }
}

void swap_array(int *a, int *b, int l)
{
    int i, t;
    for(i = 0; i<l; i ++)
    {
        t = a[i];
        a[i] = b[i];
        b[i] = t;
    }
}
int main()
{
    int n;
    cin >> n;
    char s1[M], s2[M];
    s1[0] = 1; s2[0] = 1;
    for (int i = 0; i < n; i++)
    {
        Add(s1, s2);
        swap_array(num1, num2, M);
    }
    for(int i=M;(i>=0)&&(num1[i]!=0);i--)
    {
        printf("%d",num1[i]);
    }
}
