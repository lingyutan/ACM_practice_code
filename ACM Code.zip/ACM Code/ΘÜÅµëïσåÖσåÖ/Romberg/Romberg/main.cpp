//
//  main.cpp
//  Romberg
//
//  Created by Nick Tan on 2018/6/7.
//  Copyright © 2018年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    double x[4] = {4.0/3, 7.0/6, 67.0/60, 30581.0/27720};
    double y[3], z[3], ans;
    for (int i = 1; i < 4; i++)
    {
        y[i - 1] = (4 * x[i] - x[i - 1]) / 3;
        cout << y[i - 1] << " ";
    }
    
    cout << endl;
    
    for(int i = 1; i < 3; i++)
    {
        z[i - 1] = (16 * y[i] - y[i - 1]) / 15;
        cout << z[i - 1] << " ";
    }
    
    cout << endl;
    
    ans = (64 * z[1] - z[0]) / 63;
    
    cout << ans << endl;
    
    cout << log(3);
}
