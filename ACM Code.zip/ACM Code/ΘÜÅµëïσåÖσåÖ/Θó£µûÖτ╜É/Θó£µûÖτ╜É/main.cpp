//
//  main.cpp
//  颜料罐
//
//  Created by Nick Tan on 2018/1/12.
//  Copyright © 2018年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;

int main()
{
    int n;
    long long ans = 0;
    cin >> n;
    int a[200005];
    int min = 1000000005;
    for (int i = 0; i < n; i++)
    {
        int num;
        cin >> num;
        a[i] = num;
        if(min > num) min = num;
    }
    
    for (int i = 0; i < n; i++)
    {
        a[i] -= min;
    }

    ans += n * min;
    
    int b[200005];
    for (int i = 0; i < n; i++)
        b[i] = 0;
    int j = 0;
    for (int i = 0; i < n; i++)
    {
        if(a[i] != 0) b[j] += 1;
        else j++;
    }
    b[j] += b[0];
    
    int max = 0;
    for (int i = 0; i <= j; i++)
        if(max < b[i]) max = b[i];
    
    ans += max;
    
    cout << ans << endl;
    
    return 0;
}

