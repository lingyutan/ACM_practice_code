//
//  main.cpp
//  sqrt(2)
//
//  Created by Nick Tan on 2018/5/9.
//  Copyright © 2018年 Nick Tan. All rights reserved.
//

#include <iostream>
using namespace std;

double a = 1;

int main()
{
    double b;
    while(true)
    {
        b = 0.50 * (a + 2.0 / a);
        if (a == b) break;
        a = b;
        printf("%.15f\n", a);
    }
}
