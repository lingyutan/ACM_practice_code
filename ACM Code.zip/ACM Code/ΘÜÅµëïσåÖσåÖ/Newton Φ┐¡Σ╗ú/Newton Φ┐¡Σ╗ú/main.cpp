//
//  main.cpp
//  Newton 迭代
//
//  Created by Nick Tan on 2018/6/7.
//  Copyright © 2018年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <cmath>
using namespace std;

const double eps = 1e-6;

int main()
{
    double x[100];
    
    x[0] = 9;
    
    int k = 0;
    
    while(true)
    {
        x[k + 1] = x[k] - (pow(x[k],4) + 2*pow(x[k],3) + 3*pow(x[k],2) + 4*x[k] - 5)/(4*pow(x[k],3) + 6*x[k]*x[k] + 6*x[k] + 4);
        k++;
        cout << x[k] << endl;
        if(abs(x[k] - x[k - 1]) < eps) break;
    }
}
