//
//  main.cpp
//  J - Daizhenyang's Coin
//
//  Created by tly on 2017/9/8.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

const int maxn = 100000005;

int a[maxn];

int main()
{
    int n;
    cin >> n;
    
    for (int i = 0; i < n; i++)
        scanf ("%d", &a[i]);
}
