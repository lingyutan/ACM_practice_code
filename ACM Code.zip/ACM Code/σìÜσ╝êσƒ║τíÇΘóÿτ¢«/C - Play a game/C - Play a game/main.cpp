//
//  main.cpp
//  C - Play a game
//
//  Created by tly on 2017/9/13.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    int n;
    while (scanf("%d", &n) && n)
    {
        if (n % 2) printf ("ailyanlu\n");
        else printf ("8600\n");
    }
    return 0;
}
