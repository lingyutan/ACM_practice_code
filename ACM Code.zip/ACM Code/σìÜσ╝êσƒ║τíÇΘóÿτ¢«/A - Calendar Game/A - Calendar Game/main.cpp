//
//  main.cpp
//  A - Calendar Game
//
//  Created by tly on 2017/9/8.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    
}
