#include <stdio.h>
#include <iostream>
using namespace std;
int main()
{
    int t,i,x;
    int a[10000];
    
    scanf ("%d",&t);
    for (i = 0; i < t; i++)
        scanf("%d",&x);
    
    
}
