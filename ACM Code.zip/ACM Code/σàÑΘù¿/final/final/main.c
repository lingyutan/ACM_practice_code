#include<stdio.h>
int main()
{
    printf("hello syb");
    getchar();
    printf("bye syb");
}
