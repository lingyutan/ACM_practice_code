//
//  main.cpp
//  B - Friend-Graph
//
//  Created by tly on 2017/8/24.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

int a[8][8];
int ans = 0;

int main()
{
    int T;
    scanf ("%d", &T);
    while (T--)
    {
        int n;
        scanf ("%d", &n);
        if(n > 6) ans = 1;
        else
        {
            for (int i = 1; i < n; i++)
                for (int j = 1; j < n - i + 1; j++)
                    scanf ("%d", &a[i][j]);
          
            
            for (int i = 1; i < n - 1; i++)
                for (int j = 1; j < n - i; j++)
                    for (int k = j + 1; k <= n - i; k++)
                        if (!(a[i][j] - a[i][k]) && !(a[i][k] - a[i + j][k - j]) && !(a[i + j][k - j] - a[i][j]))
                            ans = 1;
        }
        if (ans) printf ("Bad Team!\n");
        else printf ("Great Team!\n");
    }
}

// Rank 4
