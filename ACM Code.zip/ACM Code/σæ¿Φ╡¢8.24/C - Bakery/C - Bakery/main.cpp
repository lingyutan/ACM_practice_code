//
//  main.cpp
//  C - Bakery
//
//  Created by tly on 2017/8/24.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
#include <algorithm>
#include <set>
using namespace std;

int n, m, k;

struct node
{
    int u;
    int v;
    int l;
}s[100005];
set <int> storage;


bool cmp(node a, node b)
{
    return a.l < b.l;
}

int main()
{

    scanf ("%d%d%d", &n, &m, &k);
    if (k == 0)
    {
        printf("-1\n");
        return 0;
    }
    
    for (int i = 0; i < m; i++)
        scanf ("%d%d%d", &s[i].u, &s[i].v, &s[i].l);
    int h;
    for (int i = 0; i < k; i++)
    {
        scanf ("%d", &h);
        storage.insert(h);
    }
    
    sort(s, s + m, cmp);
    
    for (int i = 0; i < m; i++)
    {
        int e = 0;
        if (storage.count(s[i].u)) e++;
        if (storage.count(s[i].v)) e++;
        if(e == 1)
        {
            printf ("%d\n", s[i].l);
            return 0;
        }
    }
    printf ("-1\n");
    return 0;
}
