//
//  main.cpp
//  test0
//
//  Created by tly on 2017/8/15.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <cstdio>
#include <map>
using namespace std;

map <int, string> map_a;

int main()
{
    
}
