//
//  main.cpp
//  C - Journey
//
//  Created by tly on 2017/8/15.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <vector>
#include <cstdio>
using namespace std;

const int maxn = 100005;
vector <int> road[maxn];

double dfs(int x, int father)
{
    int k = 0;
    double l = 0;
    for (int i = 0; i < road[x].size(); i++)
        if (road[x][i] != father) k++;
    
    if (k == 0) return 0;
    
    for (int i = 0; i < road[x].size(); i++)
    {
        if (road[x][i] == father) continue;
        l += dfs(road[x][i], x) + 1;
    }
    return l / k;
}

int main()
{
    int n;
    scanf("%d", &n);
    int a, b;
    for (int i = 0; i < n - 1; i++)
    {
        scanf("%d%d", &a, &b);
        road[a].push_back(b);
        road[b].push_back(a);
    }
    double ans = dfs(1, 1);
    printf("%.15f\n", ans);
    return 0;
}
