//
//  main.cpp
//  D - An impassioned circulation of affection
//
//  Created by tly on 2017/8/15.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

char str[1500];
int n;

int main()
{
    scanf ("%d", &n);
    scanf ("%s", str);
    
    int q;
    scanf("%d", &q);
    
    while (q--)
    {
        int x;
        char c;
        scanf("%d%*c%c", &x, &c);
        
    }
}
