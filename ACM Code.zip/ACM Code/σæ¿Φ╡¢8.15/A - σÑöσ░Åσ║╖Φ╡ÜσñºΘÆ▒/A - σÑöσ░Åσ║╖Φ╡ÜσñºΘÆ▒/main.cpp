//
//  main.cpp
//  A - 奔小康赚大钱
//
//  Created by tly on 2017/8/15.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

int a[300][300];
int n;
bool b[300];
int ans;

int main()
{
    scanf("%d", &n);
    
    for (int i = 0; i < n; i++)

        
    }
}
