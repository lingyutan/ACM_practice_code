//
//  main.cpp
//  D - Sorting the Coins
//
//  Created by Nick Tan on 2017/11/8.
//  Copyright © 2017年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    
}
