//
//  main.cpp
//  A - Book Reading
//
//  Created by Nick Tan on 2017/11/8.
//  Copyright © 2017年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    int n, t;
    scanf ("%d%d", &n, &t);
    for (int i = 1; i <= n; i++)
    {
        int temp;
        scanf("%d", &temp);
        t -= 86400 - temp;
        if (t <= 0)
        {
            printf("%d\n", i);
            return 0;
        }
    }
}
