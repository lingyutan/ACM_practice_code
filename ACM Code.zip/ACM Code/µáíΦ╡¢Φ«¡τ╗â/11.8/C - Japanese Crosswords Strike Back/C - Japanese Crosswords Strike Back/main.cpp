//
//  main.cpp
//  C - Japanese Crosswords Strike Back
//
//  Created by Nick Tan on 2017/11/8.
//  Copyright © 2017年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    int n, x, t;
    scanf ("%d%d", &n, &x);
    int ans = 0;
    for (int i = 0; i < n; i++){
        scanf ("%d", &t);
        ans += t;
    }
    if (ans + n == x + 1) printf("YES\n");
    else printf("NO\n");
    return 0;
}
