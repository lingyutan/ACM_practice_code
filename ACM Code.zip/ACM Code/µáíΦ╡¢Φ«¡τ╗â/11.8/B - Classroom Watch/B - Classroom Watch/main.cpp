//
//  main.cpp
//  B - Classroom Watch
//
//  Created by Nick Tan on 2017/11/8.
//  Copyright © 2017年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

int count(int x)
{
    int ans = 0;
    while(x >= 10)
    {
        ans += x % 10;
        x = x / 10;
    }
    ans += x;
    return ans;
}

int main()
{

    int n;
    scanf ("%d", &n);
    int num = 0;
    int b[100];
    for (int j = n - 100; j < n; j++){
        if (j + count(j) == n)
            b[num++] = j;
    }
    int z = 0;
    printf ("%d\n", num);
    while (num--){
        printf("%d", b[z++]);
    }
    return 0;
}
