//
//  main.cpp
//  B - Nikita and string
//
//  Created by Nick Tan on 2017/11/16.
//  Copyright © 2017年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int main()
{
    char c[5001];
    scanf("%s", c);
    int a[5001];
    for (int i = 0; i < 5001; i++)
        a[i] = 1;
    int j = 0;
    for (int i = 0; i < strlen(c) - 1; i++)
    {
        if (c[i + 1] == c[i]) a[j]++;
        else j++;
    }
    a[j + 1] = 0;
    a[j + 2] = 0;
    
    int x = 0;
    if (c[0] == 'b') x = 1;
    
    int maxn = 0;
    for (int i = x; i <= j; i += 2)
        maxn = max(maxn, a[i] + a[i + 1] + a[i + 2]);
    
    cout << maxn << endl;
}
