//
//  main.cpp
//  A - Red and Black
//
//  Created by Nick Tan on 2017/11/13.
//  Copyright © 2017年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

int d[4][2] = {1, 0, -1, 0, 0, 1, 0, -1};
int W, H;
char a[21][21];
int ans;

bool check(int x, int y)
{
    return x >= 0 && x < W && y >= 0 && y < H;
}

void dfs(int x, int y)
{
    if(!check(x, y) || a[y][x] == '#')
        return;
    ans++;
    a[y][x] = '#';
    for (int i = 0; i < 4; i++)
        dfs(x + d[i][0], y + d[i][1]);
}

int main()
{
    while (scanf ("%d%d", &W, &H) && W && H)
    {
        ans = 0;
        for (int i = 0; i < H; i++)
            scanf("%s", a[i]);
        
        int startx = 0;
        int starty = 0;
        
        for (int i = 0; i < H; i++)
            for (int j = 0; j < W; j++)
                if (a[i][j] == '@')
                {
                    startx = j;
                    starty = i;
                }
        dfs(startx, starty);
        printf("%d\n", ans);
    }
    return 0;
}
