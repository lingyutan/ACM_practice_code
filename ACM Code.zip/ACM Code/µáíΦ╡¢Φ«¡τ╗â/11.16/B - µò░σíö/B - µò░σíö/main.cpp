//
//  main.cpp
//  B - 数塔
//
//  Created by Nick Tan on 2017/11/16.
//  Copyright © 2017年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    int C;
    cin >> C;
    int a[100][100];
    
    while (C--){
        int N;
        cin >> N;
        for (int i = 0; i < N; i++)
            for (int j = 0; j <= i; j++)
                scanf ("%d", &a[i][j]);
        
        for (int i = N - 2; i >= 0; i--)
            for (int j = 0; j <= i; j++)
                a[i][j] += max(a[i + 1][j], a[i + 1][j + 1]);
        
        cout << a[0][0] << endl;
    }
}
