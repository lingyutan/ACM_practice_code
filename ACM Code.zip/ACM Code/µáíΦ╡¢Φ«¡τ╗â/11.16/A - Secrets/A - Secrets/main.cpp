//
//  main.cpp
//  A - Secrets
//
//  Created by Nick Tan on 2017/11/16.
//  Copyright © 2017年 Nick Tan. All rights reserved.
//

#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    long long n;
    cin >> n;
    while(true){
        if (n % 3 == 0){
            n /= 3;
        }
        else{
            n /= 3;
            break;
        }
    }
    cout << n + 1 << endl;
}
