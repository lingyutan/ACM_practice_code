//
//  main.cpp
//  L - 免费馅饼
//
//  Created by tly on 2017/8/16.
//  Copyright © 2017年 admin. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
